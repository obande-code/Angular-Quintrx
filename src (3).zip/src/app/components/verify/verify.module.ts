import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VerifyRoutingModule } from './verify-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    VerifyRoutingModule
  ]
})
export class VerifyModule { }
