import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-menu',
  templateUrl: './manage-menu.component.html',
  styleUrls: ['./manage-menu.component.scss']
})
export class ManageMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
