import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-package',
  templateUrl: './order-package.component.html',
  styleUrls: ['./order-package.component.scss']
})
export class OrderPackageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
