import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewpackageRoutingModule } from './viewpackage-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ViewpackageRoutingModule
  ]
})
export class ViewpackageModule { }
