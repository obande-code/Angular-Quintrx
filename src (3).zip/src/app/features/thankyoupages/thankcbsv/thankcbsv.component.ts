import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thankcbsv',
  templateUrl: './thankcbsv.component.html',
  styleUrls: ['./thankcbsv.component.scss']
})
export class ThankcbsvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
