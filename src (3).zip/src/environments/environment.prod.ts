export const environment = {
  production: true,

  api_url : 'https://vetzu-java-dev.azurewebsites.net',
  //api_url : 'https://quintrxprod.azurewebsites.net',
  //api_url: 'http://localhost:8080',

  appVersion: 'vetzu',
  USER_DATA_KEY: 'uhj78swwAsqml',
};
