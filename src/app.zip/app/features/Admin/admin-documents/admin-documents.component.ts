import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-documents',
  templateUrl: './admin-documents.component.html',
  styleUrls: ['./admin-documents.component.scss']
})
export class AdminDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
