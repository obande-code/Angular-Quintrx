import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acceptancemsg',
  templateUrl: './acceptancemsg.component.html',
  styleUrls: ['./acceptancemsg.component.scss']
})
export class AcceptancemsgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
