import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrderPackageRoutingModule } from './order-package-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    OrderPackageRoutingModule
  ]
})
export class OrderPackageModule { }
