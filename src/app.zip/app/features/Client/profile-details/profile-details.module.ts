import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileDetailsRoutingModule } from './profile-details-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ProfileDetailsRoutingModule
  ]
})
export class ProfileDetailsModule { }
