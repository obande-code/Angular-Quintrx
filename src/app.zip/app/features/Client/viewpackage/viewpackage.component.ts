import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewpackage',
  templateUrl: './viewpackage.component.html',
  styleUrls: ['./viewpackage.component.scss']
})
export class ViewpackageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
