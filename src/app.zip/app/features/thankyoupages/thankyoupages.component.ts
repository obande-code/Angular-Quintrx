import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thankyoupages',
  templateUrl: './thankyoupages.component.html',
  styleUrls: ['./thankyoupages.component.scss']
})
export class ThankyoupagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
